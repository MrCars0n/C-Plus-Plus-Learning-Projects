// In-Class Exercise:  Participation Lab 1
// Professor M 
// CSCN 112 Spring 2023

#include <iostream> // used for cout/cin input and output streams
#include <string> // necessary to use getline
#include "basketballGame.h"

using namespace std;

int main()
{
	// Let's say I want to store the information for a basketball game
	// Local variables 
	basketballGame game1;

	cout << "What is the name of our team? " << endl;
	string temp_Name;
	getline(cin, temp_Name);

	game1.setTeamName(temp_Name);

	cout << "What is the opponent you are currently facing? " << endl;
	getline(cin, temp_Name);

	game1.setOpponentName(temp_Name);

	cout << "At the end of the game, what is the opponent's score? " << endl;
	int temp_Score;
	cin >> temp_Score;

	while (cin.fail() || temp_Score < 0 || temp_Score > 100)
	{
		cin.clear(); // clear out the error state from the cin stream
		cin.ignore(10000, '\n'); // ignore anything else in the input stream
		cout << "Error retrieving score.  Please enter the opponent's score for the game : " << endl;
		cin >> temp_Score;
	}

	game1.setOppScore(temp_Score);

	cout << "At the end of the game, what is our current team's score? " << endl;
	cin >> temp_Score;
	while (cin.fail() || temp_Score < 0 || temp_Score > 100)
	{
		cin.clear();  // clear out the error state from the cin stream
		cin.ignore(1000, '\n'); // ignore anything else in the input stream
		cout << "Error retrieving score.  Please enter our team's score for the game: " << endl;
		cin >> temp_Score;
	}

	game1.setOurScore(temp_Score);

	cout << "Our opponent is " << game1.getOpponentName() << " and the final score is " <<
		game1.getOpponentName() << ": " << game1.getOppScore() << " " << game1.getTeamName() << ": " << game1.getOurScore() << endl
		<< endl;
	if (game1.getOurScore() > game1.getOppScore())
		cout << "We win!" << endl;
	else
		cout << game1.getOpponentName() << " wins the game." << endl;
	system("pause");
	return 0;
}